---
name: research-planner
description: "Ordena investigaciones de Ikariam, prerrequisitos, academias, experimentos, futuros y mejoras de taller según los objetivos de la cuenta."
---

# Plan de investigación

Lee investigacion y las notas de versiones. Las ramas son Navegación, Economía, Ciencia, Milicia y Mitología. El taller es distinto de la academia.

Identifica objetivo, tecnologías ya confirmadas, prerrequisitos pendientes y coste total. Consulta información actual cuando haga falta un coste o desbloqueo exacto. No confundas puntos disponibles con puntos acumulados históricamente ni con puntuación de investigadores.

Usa `calculate` operation=research_eta con producción neta y puntos reales. Trata experimentos y recompensas como entradas aparte; usa coste y resultado vistos en la interfaz. Analiza el impacto de aumentar científicos en el saldo de oro y verifica que haya población suficiente.

En futuros, registra rama y nivel; en taller, unidad o barco y nivel de cada mejora. No reutilices tablas anteriores a los cambios militares como estadísticas actuales. Compara beneficios en el horizonte que importa al usuario y guarda la secuencia como entrada research o plan cuando se pida.
