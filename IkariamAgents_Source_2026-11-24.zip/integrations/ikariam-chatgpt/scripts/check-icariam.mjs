import {execFileSync} from 'node:child_process';
import {buildSync} from 'esbuild';
import {mkdirSync} from 'node:fs';
mkdirSync('outputs',{recursive:true});
buildSync({entryPoints:['lib/icariam/service.ts'],bundle:true,platform:'node',format:'esm',packages:'external',outfile:'outputs/service-test.mjs'});
execFileSync(process.execPath,['--test','tests/engine.test.mjs','tests/service.test.mjs','tests/combat.test.mjs'],{stdio:'inherit'});
