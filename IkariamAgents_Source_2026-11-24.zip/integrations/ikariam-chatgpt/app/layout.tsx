import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Ikariam · Cuartel de mando',
  description: 'Mapa de Atlas, inventario de ciudades y planificación de tu imperio.',
  icons: { icon: '/favicon.svg' },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
